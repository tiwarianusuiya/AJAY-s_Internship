WANDB_API_KEY = "paste_your_wandb_API_key"
